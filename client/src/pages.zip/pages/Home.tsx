// File: src/pages/Home.tsx
import React, { useState } from 'react';
import { ProductCard } from '../components/ProductCard';
import { ProductModal } from '../components/ProductModal';
import { Product } from '../types';
import { Chatbot } from '../components/chatbot';
import img1 from '../assets/1.jpg';
import img2 from '../assets/2.jpg';
import img3 from '../assets/3.jpg';
import img4 from '../assets/4.jpg';
import img5 from '../assets/5.jpg';
import img6 from '../assets/6.jpg';
import img7 from '../assets/7.jpg';
import img8 from '../assets/8.jpg';

const products: Product[] = [
  {
    id: '1',
    name: 'Aurora Watch',
    description: 'A sleek timepiece inspired by the Northern Lights.',
    price: 199.99,
    image: img1,
    category: 'Watches',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
  },
  {
    id: '2',
    name: 'Polar Bag',
    description: 'Warmth and style for any adventure.',
    price: 129.99,
    image: img2,
    category: 'Bags',
    videoUrl: 'https://www.youtube.com/embed/VIDEO_ID_2',
  },
  {
    id: '3',
    name: 'Midnight Bag',
    description: 'Illuminate your space with elegance.',
    price: 59.99,
    image: img3,
    category: 'Bags',
  },
  {
    id: '4',
    name: 'Creme Cycle',
    description: 'Illuminate your space with elegance.',
    price: 898.99,
    image: img4,
    category: 'Cycles',
  },
  {
    id: '5',
    name: 'Crimson Lamp Perfume',
    description: 'Illuminate your space with elegance.',
    price: 77.99,
    image: img5,
    category: 'Perfumes',
  },
  {
    id: '6',
    name: 'Champ Cycle',
    description: 'Illuminate your space with elegance.',
    price: 8989.99,
    image: img6,
    category: 'Cycles',
  },
  {
    id: '7',
    name: 'Kaiju Watch',
    description: 'Illuminate your space with elegance.',
    price: 2323.99,
    image: img7,
    category: 'Watches',
  },
  {
    id: '8',
    name: 'Ninga H4',
    description: 'Illuminate your space with elegance.',
    price: 10000.99,
    image: img8,
    category: 'Electronics',
  },
];
export const Home = () => {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [suggestedCategory, setSuggestedCategory] = useState<string | null>(null);
  const [filterCategory, setFilterCategory] = useState<string | null>(null);

  const openModal = (product: Product) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    if (selectedProduct) {
      setSuggestedCategory(selectedProduct.category);
    }
    setSelectedProduct(null);
  };

  const displayedProducts = filterCategory
    ? products.filter((p) => p.category === filterCategory)
    : products;

  return (
    <div className="pt-20 pb-12">
      <div className="text-center my-8">
        <div className="flex items-center justify-center gap-4">
          {filterCategory && (
            <button
              onClick={() => setFilterCategory(null)}
              className="text-white hover:text-gray-300 text-2xl"
              aria-label="Clear filter"
            >
              &larr;
            </button>
          )}
          <h1 className="text-4xl font-bold text-white animate-fade-in">
            {filterCategory ? "Recommended Products" : "Featured Products"}
          </h1>
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 px-4 max-w-7xl mx-auto">
        {displayedProducts.map((product) => (
          <ProductCard key={product.id} product={product} onAskAI={openModal} />
        ))}
      </div>

      {isModalOpen && selectedProduct && (
        <ProductModal product={selectedProduct} onClose={closeModal} />
      )}

      {suggestedCategory && !isModalOpen && (
        <div className="fixed bottom-4 right-4 bg-white p-4 rounded shadow-lg z-50">
          <button
            onClick={() => setSuggestedCategory(null)}
            className="absolute top-2 right-2 text-sm text-gray-600 hover:text-gray-800"
            aria-label="Dismiss banner"
          >
            ×
          </button>
          <button
            onClick={() => {
              setFilterCategory(suggestedCategory);
              setSuggestedCategory(null);
            }}
            className="text-blue-600 hover:underline"
          >
            We have suggested products based on your activity. Click here to view products in {suggestedCategory}.
          </button>
        </div>
      )}
         <Chatbot />
    </div>
  );
};